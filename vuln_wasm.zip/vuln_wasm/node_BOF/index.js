const Module = require('./wasm.js');
const express = require('express');
const app = express();
const port = 3000;

// Middleware to serve static files and parse URL-encoded data
app.use(express.urlencoded({ extended: true }));

var executeWasm;
console.log("DEBUG");
var result = Module.onRuntimeInitialized = () => {
  console.log("LOADED");
  executeWasm = function executeWasm(name) {
    const ptr = Module.allocate(
      Module.intArrayFromString(name),
      Module.ALLOC_NORMAL
    );
    Module._greetings(ptr);
    Module._free(ptr);
  };
};

// Route to display the HTML form
app.get('/', (req, res) => {
  const html = `
    <html>
      <head>
        <title>WASM Input</title>
      </head>
      <body>
        <h1>Enter Your Name</h1>
        <form method="POST" action="/submit-name">
          <label for="name">Name:</label>
          <input type="text" id="name" name="name" required>
          <button type="submit">Submit</button>
        </form>
      </body>
    </html>
  `;
  res.send(html);
});

// Route to handle form submission
app.post('/submit-name', (req, res) => {
  let name = req.body.name; // Access form data
  if (!name) {
    res.send("Name cannot be empty!");
    return;
  }
  try {
    executeWasm(name); // Execute WebAssembly function
    res.send(`Thank you, ${name}, for sending us your name!`);
  } catch (error) {
    console.error("Error executing WebAssembly function:", error);
    res.status(500).send("An error occurred while processing your request.");
  }
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});